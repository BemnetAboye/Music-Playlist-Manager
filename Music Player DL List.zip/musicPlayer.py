# Author: Bemnet Aboye
# Date: 2/09/2025
# Purpose: A program manages a music playlist using a doubly linked list, enabling efficient song addition, removal, and navigation.
class SongNode:
    def __init__(self, title, artist, duration):
        self.title = title
        self.artist = artist
        self.duration = duration  # Duration in seconds
        self.next = None
        self.prev = None

class Playlist:
    def __init__(self):
        self.head = None
        self.tail = None

    def add_song(self, title, artist, minutes, seconds):
        duration = minutes * 60 + seconds
        new_song = SongNode(title, artist, duration)
        if not self.head:
            self.head = self.tail = new_song
        else:
            self.tail.next = new_song
            new_song.prev = self.tail
            self.tail = new_song
        print(f"Added: {title} by {artist}")

    def remove_song(self, title):
        current = self.head
        while current:
            if current.title.lower() == title.lower():
                if current.prev:
                    current.prev.next = current.next
                else:
                    self.head = current.next
                if current.next:
                    current.next.prev = current.prev
                else:
                    self.tail = current.prev
                print(f"Removed: {title}")
                return
            current = current.next
        print(f"Song '{title}' not found.")

    def display(self):
        if not self.head:
            print("Playlist is empty.")
            return
        print("\nPlaylist:")
        current = self.head
        while current:
            minutes, seconds = divmod(current.duration, 60)
            print(f"{current.title} - {current.artist} [{minutes}:{seconds:02d}]")
            current = current.next

    def play_next(self):
        if self.head:
            current_song = self.head
            print(f"Now Playing: {current_song.title} - {current_song.artist}")
            self.head = self.head.next
            if self.head:
                self.head.prev = None
            else:
                self.tail = None
            # Simulate playing time
            # time.sleep(current_song.duration)
        else:
            print("No more songs in the playlist.")

    def load_from_file(self, filename="playlist.txt"): # Default filename
        try:
            with open(filename, 'r') as file:
                for line in file:
                    try:  # Handle potential errors in individual lines
                        title, artist, minutes, seconds = line.strip().split(',')
                        self.add_song(title, artist, int(minutes), int(seconds))
                    except ValueError:
                        print(f"Skipping invalid line: {line.strip()}")  # Informative message
            print("Songs loaded successfully!")
        except FileNotFoundError:
            print(f"File '{filename}' not found. Creating an empty playlist.") # More helpful message
        except Exception as e: # Catch other potential errors during file reading
            print(f"An error occurred while loading: {e}")

    def sort_playlist(self, key):
        if key not in ["title", "artist", "duration"]:
            print("Invalid sorting key!")
            return

        if not self.head or not self.head.next:
            print("Playlist is too short to sort.")
            return

        # Convert linked list to list for sorting
        songs = []
        current = self.head
        while current:
            songs.append(current)
            current = current.next

        # Sort the list
        songs.sort(key=lambda song: getattr(song, key))

        # Rebuild the linked list
        self.head = songs[0]
        self.head.prev = None
        current = self.head
        for song in songs[1:]:
            current.next = song
            song.prev = current
            current = song
        self.tail = current
        self.tail.next = None

        print(f"Playlist sorted by {key}.")

def main():
    playlist = Playlist()
    playlist.load_from_file() # Load from playlist.txt by default

    options = {
        "1": ("Add a Song", lambda: playlist.add_song(
            input("Enter song title: "),
            input("Enter artist: "),
            int(input("Enter duration (minutes): ")),
            int(input("Enter duration (seconds): "))
        )),
        "2": ("Remove a Song", lambda: playlist.remove_song(input("Enter song title to remove: "))),
        "3": ("Display Playlist", playlist.display),
        "4": ("Play Next Song", playlist.play_next),
        "5": ("Load Songs from File", lambda: playlist.load_from_file(input("Enter filename to load songs from (or press Enter for playlist.txt): ") or "playlist.txt")), # Allow user to specify filename
        "6": ("Sort Playlist", lambda: playlist.sort_playlist(input("Sort by (title/artist/duration): "))),
        "7": ("Exit", exit)
    }

    while True:
        print("\nMusic Playlist Manager")
        for key, (desc, _) in options.items():
            print(f"{key}. {desc}")
        choice = input("Enter choice: ")
        action = options.get(choice)
        if action:
            action[1]()
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()